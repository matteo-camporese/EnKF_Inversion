# Are we master or slave?

global master = 0;
global slave = 1;
global caste = master;

Run_Parallel;

