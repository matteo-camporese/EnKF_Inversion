function Generate_Forward_Run

par(1:18)=100;
par(8)=1000;
Write_Rho_Coarse(par);
[s,w]=dos('CRMod.exe');

fid = fopen('volt.dat','r');
[NrArrays]=fscanf(fid,'%g',[1 1]);
for i=1:NrArrays
Meas_Data(i,1:3)=fscanf(fid,'%g %g %g',[1 3]);
end
fclose(fid);

fid = fopen('meas_data.txt','wt');

for i=1:NrArrays
fprintf(fid,'%16.6f\n',Meas_Data(i,3));
end
fclose(fid);