tic
load rand_par.txt;
load meas_data.txt;

N=size(rand_par,1);

for i=1:N
  par=rand_par(i,:);
  [OF(i)]=Calc_OF(par,meas_data);
  i
end

t=toc

  