% Are we master or slave?

global master = 0;
global slave = 1;
global caste = slave;

%js runscem;
Run_Parallel;

