function Generate_Forward_Run_Layers

% read the true distribution of hydraulic conductivity [L/T]
parmc=load('round.txt');
% count=1;

% noise = zeros(1800,1);
% noise=randn([1800 1])*100;

% for i=1:60
%     for j=1:30
%         if (j<=depth(i))
%             parmc(1,count)=10+noise(count);
%         else
%             parmc(1,count)=100+noise(count)*0.1;
%         end
%         count=count+1;
%     end
% end
parmc=switchgrid(parmc,30,60);
% x=[0:60];
% y=[0:30];
%
% test=reshape(par',[30 60]);
% test(31,:)=test(30,:);
% test(:,61)=test(:,60);
% pcolor(x,y,log10(test)),caxis([1 4]),colorbar,

% Renumber parameters for mcfean grid
% parmc=switchgrid(par,30,60);
% Call mcfean
disp('call mcfean');
cd mcfean
Write_Kappa(parmc);
[s,w]=unix('./mcfeansf');
% Open concentration data and transform into sigma values
[nstep,ndim,conc]=plume;
sigma=9.004.*conc+0.0021;
% Call crmod
cd ../crmod
MEAS_DATA=[];
disp('call crmod');
for t=1:nstep;
    bot=(t-1)*ndim+1;
    top=t*ndim;
    par=1./sigma(bot:top);
    par=switchgrid(par,30,60);
    Write_Rho(par);
    [s,w]=unix('./CRUnix.exe');
    fid = fopen('volt.dat','r');
    [NrArrays]=fscanf(fid,'%g',[1 1]);
    for i=1:NrArrays
        Meas_Data(i,1:3)=fscanf(fid,'%g %g %g',[1 3]);
    end
    fclose(fid);
    MEAS_DATA=[MEAS_DATA; Meas_Data];
end
cd ..

fid = fopen('meas_data.txt','wt');

for i=1:NrArrays*nstep
    fprintf(fid,'%16.6f\n',MEAS_DATA(i,3));
end
fclose(fid);