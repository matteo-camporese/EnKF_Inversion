function [Measurement]=Generate_Roughness(Measurement);


% Generate roughness of 3*6 matrix

Rough=zeros([18,18]);

count = 1;

for i=1:6
    for j=1:3
        
        if (i==1)
            if (j==1)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count+3)=-1;
            end
            if (j==2)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count+3)=-1;
            end          
            if (j==3)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count+3)=-1;
            end
        end

        if (i==6)
            if (j==1)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count-3)=-1;
            end
            if (j==2)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count-3)=-1;
            end          
            if (j==3)
              Rough(count,count)=2;
              Rough(count,count-1)=-1;
              Rough(count,count-3)=-1;
            end
        end
        
        if (i>1)&(i<6)
            if (j==1)
              Rough(count,count)=3;
              Rough(count,count+3)=-1;
              Rough(count,count+1)=-1;
              Rough(count,count-3)=-1;
            end
            if (j==2)
              Rough(count,count)=4;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count-3)=-1;
              Rough(count,count+3)=-1;
            end          
            if (j==3)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;
              Rough(count,count-3)=-1;
              Rough(count,count+3)=-1;
            end
        end
        count=count+1;
    end
end

Measurement.Rough18=Rough;

% Generate roughness of 6*12 matrix

Rough=zeros([72,72]);

count = 1;
NrCols=12;
NrRows=6;

for i=1:NrCols
    for j=1:NrRows
        
        if (i==1)
            if (j==1)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end
        end

        if (i==NrCols)
            if (j==1)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=2;
              Rough(count,count-1)=-1;
              Rough(count,count-NrRows)=-1;
            end
        end
        
        if (i>1)&(i<NrCols)
            if (j==1)
              Rough(count,count)=3;
              Rough(count,count+NrRows)=-1;
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=4;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
              Rough(count,count+NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;
              Rough(count,count-NrRows)=-1;
              Rough(count,count+NrRows)=-1;
            end
        end
        count=count+1;
    end
end

Measurement.Rough72=Rough;

% Generate roughness of 15*30 matrix

Rough=zeros([450,450]);

count = 1;
NrCols=30;
NrRows=15;

for i=1:NrCols
    for j=1:NrRows
        
        if (i==1)
            if (j==1)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end
        end

        if (i==NrCols)
            if (j==1)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=2;
              Rough(count,count-1)=-1;
              Rough(count,count-NrRows)=-1;
            end
        end
        
        if (i>1)&(i<NrCols)
            if (j==1)
              Rough(count,count)=3;
              Rough(count,count+NrRows)=-1;
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=4;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
              Rough(count,count+NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;
              Rough(count,count-NrRows)=-1;
              Rough(count,count+NrRows)=-1;
            end
        end
        count=count+1;
    end
end

Measurement.Rough450=Rough;

% Generate roughness of 30*60 matrix

Rough=zeros([1800,1800]);

count = 1;
NrCols=60;
NrRows=30;

for i=1:NrCols
    for j=1:NrRows
        
        if (i==1)
            if (j==1)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count+NrRows)=-1;
            end
        end

        if (i==NrCols)
            if (j==1)
              Rough(count,count)=2;
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=2;
              Rough(count,count-1)=-1;
              Rough(count,count-NrRows)=-1;
            end
        end
        
        if (i>1)&(i<NrCols)
            if (j==1)
              Rough(count,count)=3;
              Rough(count,count+NrRows)=-1;
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
            end
            if (j>1) & (j<NrRows)
              Rough(count,count)=4;
              Rough(count,count-1)=-1;              
              Rough(count,count+1)=-1;
              Rough(count,count-NrRows)=-1;
              Rough(count,count+NrRows)=-1;
            end          
            if (j==NrRows)
              Rough(count,count)=3;
              Rough(count,count-1)=-1;
              Rough(count,count-NrRows)=-1;
              Rough(count,count+NrRows)=-1;
            end
        end
        count=count+1;
    end
end

Measurement.Rough1800=Rough;