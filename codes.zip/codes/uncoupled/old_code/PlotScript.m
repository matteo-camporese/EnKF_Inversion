% PlotScript

[M,N] = size(StoredBest);

X = [0:30];
Y = [0:-1:-15];


Best = zeros(15,30);

      figure(3)
      for k = 1:30
            for l = 1:15
                  Best(l,k) = log10(StoredBest(1000,(k-1)*15+l));
            end;
      end;
      
      tmp1 = [Best Best(:,30)];
      tmp2 = [tmp1;tmp1(15,:)];
      
      
      
      pcolor(X,Y,tmp2), caxis([0 4]), colorbar
      axis equal
      xlim([0 30]);
      ylim([-15 0]);
    
      xlabel('x [m]','FontWeight','bold','FontSize',18,'FontName','Times New Roman');
      ylabel('z [m]','FontWeight','bold','FontSize',18,'FontName','Times New Roman');

figure(2)
semilogy(StoredBest(:,N-2),'LineWidth',3)
      xlabel('Generation [-]','FontWeight','bold','FontSize',18,'FontName','Times New Roman');
      ylabel('Objective function [-]','FontWeight','bold','FontSize',18,'FontName','Times New Roman');


