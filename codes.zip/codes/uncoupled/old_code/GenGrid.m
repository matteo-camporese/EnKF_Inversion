count=1;

%Define dimensions of grid
NodesH=61;
NodesV=31;
NrCols=NodesH-1;
NrRows=NodesV-1;

% Define electrode layout
NrElec=21;
ElecPos1=10*NodesV+1;


fid = fopen('elem.dat','wt');

for i=1:NodesH
    for j=1:NodesV
        X=0+(i-1)*0.5;
        Y=0-(j-1)*0.5;
        nodes(count,1:3)=[count, X, Y];
        count=count+1;
    end
end
   

count=1;

for i=1:NrCols
    for j=1:NrRows
            elem(count,1:4)=[(j+1)+(i-1)*NodesV,(j+1)+(i)*NodesV,j+i*NodesV,j+(i-1)*NodesV];
            count=count+1;
    end
end

%Determine Boundary Nodes

count=1;

for i=1:NrCols
    node1=1+(i-1)*NodesV;
    node2=1+i*NodesV;
    BorderNode(count,1:2)=[node1,node2];
    count=count+1;
end


for i=1:NrRows
    node1=i+NodesH*NodesV-NodesV;
    node2=node1+1;
    BorderNode(count,1:2)=[node1,node2];
    count=count+1;
end

for i=1:NrCols
    node1=NodesV*NodesH-(i-1)*NodesV;
    node2=node1-NodesV;
    BorderNode(count,1:2)=[node1,node2];
    count=count+1;
end

for i=1:NrRows
    node1=NodesV+1-i;
    node2=node1-1;
    BorderNode(count,1:2)=[node1,node2];
    count=count+1;
end

%Determine Boundary Elements

count=1;

for i=1:NrCols
    BorderElem(count)= (i-1)*NrRows+1;
    count=count+1;
end


for i=1:NrRows
    BorderElem(count)= NrCols*NrRows-NrRows+i;
    count=count+1;
end

for i=1:NrCols
    BorderElem(count)= NrCols*NrRows-(i-1)*NrRows;
    count=count+1;
end

for i=1:NrRows
    BorderElem(count)= NrRows+1-i;
    count=count+1;
end

NrNodes=NodesV*NodesH;
NrElemType=3;
Band=33;
fprintf(fid,'%6.0f %6.0f  %6.0f\n',NrNodes,NrElemType,Band);

Type=8;
NrElem=NrCols*NrRows;
NrNodesElem=4;
fprintf(fid,'%6.0f %6.0f  %6.0f\n',Type,NrElem,NrNodesElem);

Type=12;
NrElem=NrCols;
NrNodesElem=2;
fprintf(fid,'%6.0f %6.0f  %6.0f\n',Type,NrElem, NrNodesElem);

Type=11;
NrElem=NrCols+2*NrRows;
NrNodesElem=2;
fprintf(fid,'%6.0f %6.0f  %6.0f\n',Type,NrElem, NrNodesElem);

for i=1:(NodesV*NodesH)
fprintf(fid,'%6.0f %6.2f  %6.2f\n',nodes(i,:));
end

for i=1:(NrCols*NrRows)
fprintf(fid,'%6.0f %6.0f  %6.0f %6.0f\n',elem(i,:));
end

for i=1:2*(NrCols+NrRows)
fprintf(fid,'%6.0f %6.0f\n',BorderNode(i,:));
end

for i=1:2*(NrCols+NrRows)
fprintf(fid,'%6.0f\n',BorderElem(i));
end
fclose(fid);

fid = fopen('elec.dat','wt');

for i=1:NrElec
ElecPos(i)=ElecPos1+(i-1)*2*NodesV;
end

fprintf(fid,'%6.0f\n',NrElec);

for i=1:NrElec
fprintf(fid,'%6.0f\n',ElecPos(i));
end

fclose(fid);

% Write the rho.dat file
fid = fopen('rho.dat','wt');
NrElem=NrCols*NrRows;

fprintf(fid,'%6.0f\n',NrElem);

rho=ones([NrElem,1])*100;

for i=1:NrElem
fprintf(fid,'%6.0f\n',rho(i));
end

fclose(fid);

%Generate the electrode arrays

fid = fopen('config2.dat','wt');

count=1;

% Generate Wenner Arrays
for j=1:5
for i=1:j:18
 elec1=i;
 elec2=i+1*j;
 elec3=i+2*j;
 elec4=i+3*j;
 if (elec4<=21)
 Elec_Pairs(count,1)=elec1*10000+elec4;
 Elec_Pairs(count,2)=elec2*10000+elec3;
 count=count+1;
 end
end
end

% Generate Schlumberger Arrays

for j=5:2:21
for i=1:18
 elec1=i;
 elec2=i+0.5*(j-1);
 elec3=i+0.5*(j+1);
 elec4=i+j;
 if (elec4<=21)
 Elec_Pairs(count,1)=elec1*10000+elec4;
 Elec_Pairs(count,2)=elec2*10000+elec3;
 count=count+1;
 end
end
end

% Generate Dipole-Dipole

for i=1:18
for j=(i+2):(i+5)
    elec1=i;
    elec4=i+1;
    elec2=j;
    elec3=j+1;
 if (elec3<=21)
 Elec_Pairs(count,1)=elec1*10000+elec4;
 Elec_Pairs(count,2)=elec2*10000+elec3;
 count=count+1;
 end
end
end
   
for i=1:2:18
for j=(i+4):2:(i+10)
    elec1=i;
    elec4=i+2;
    elec2=j;
    elec3=j+2;
 if (elec3<=21)
 Elec_Pairs(count,1)=elec1*10000+elec4;
 Elec_Pairs(count,2)=elec2*10000+elec3;
 count=count+1;
 end
end
end

NrArrays=size(Elec_Pairs,1);

fprintf(fid,'%6.0f\n',NrArrays);

for i=1:NrArrays
fprintf(fid,'%8.0f %8.0f\n',Elec_Pairs(i,1), Elec_Pairs(i,2));
end


fclose(fid);

