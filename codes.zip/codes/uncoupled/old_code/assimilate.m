% function [dx, A] = assimilate(prm, A, HA, dy)
%
% Calculates correction of the ensemble mean and updates the ensemble anomalies.
%
% @param prm - system parameters
% @param A - ensemble anomalies (n x m)
% @param HA - ensemble observations (p x m)
% @param dy - vector of increments, dy = y - Hx (p x 1)
% @return dx - correction of the mean dx = K dy
% @return A - updated ensemble anomalies

% File:           assimilate.m
%
% Created:        23/03/2009
%
% Last modified:  19/11/2009
%
% Author:         Pavel Sakov
%                 NERSC
%
% Purpose:        Contains core code for asynchronous data assimilation with the
%                 EnKF.
%
% Description:    This procedure calculates the analysis correction and updates
%                 the ensemble by applying scheme specified by prm.method.
%                 It assumes that the system runs in the asynchronous regime,
%                 i.e. that both increments `dy' and ensemble observations `HA'
%                 contain values recorded at the time of observations.
%                 There are some differences with the assimilate.m that handles
%                 synchronous observations:
%                 (i) There are no batches of observations anymore. If there
%                     are too many observations - one can always use LA
%                     localisation and conduct analysis in the ensemble space
%                 (ii) Not all schemes are available for every localisation
%                     method. Following are the lists of available schemes for
%                     each method.
%                     * With no localisation or with LA:
%                       EnKF
%                       DEnKF
%                       ETKF
%                       Potter
%                       EnOI
%                     * With CF:
%                       EnKF
%                       DEnKF
%                       EnOI
%
% Revisions:

%                 1.10.2009 PS:
%                   -- Fixed a defect in the EnKF scheme (an extra division by
%                      sqrt(r) for D)
%                   -- Introduced CF localisation, with only three schemes at
%                      the moment: EnKF, DEnKF and EnOI
%                 19.11.2009 PS:
%                   -- Updated description in the file header
%                 5.8.2010 PS:
%                   -- Modified LA part to accommodate "rfactor"
%                 25/08/2010 PS:
%                   - This file, formerly known as assimilate_a.m, now replaced
%                     the previous (synchronous) version of assimilate.m

%% Copyright (C) 2009 Pavel Sakov
%%
%% This file is part of EnKF-Matlab. EnKF-Matlab is a free software. See
%% LICENSE for details.

function [dx, A] = assimilate(prm, A, HA, dy)

m = prm.m;
n = prm.n;
r = prm.obs_variance * prm.rfactor1;
rfactor = prm.rfactor2;
p = size(HA, 1);
% np = prm.nprm;
% ns = n - np;

if p < 1
    dx = zeros(n, 1);
    return
end

% we now follow
%   Sakov, P., G. Evensen, and L. Bertino (2010): Asynchronous data
%   assimilation with the EnKF. Tellus 62A, 24-29.

s = dy / sqrt(r * (m - 1));
S = HA / sqrt(r * (m - 1));

% calculate global perturbations for the EnKF
%
if strcmp(prm.method, 'EnKF')
    D = randn(p, m) / (rfactor * sqrt(m - 1));
    d = mean(D')';
    D = sqrt(m / (m - 1)) * (D - repmat(d, 1, m));
end

if strcmp(prm.method, 'ETKF')
    M = inv(speye(m) + S' * S);
    G = M * S';
elseif m <= p
    G = inv(speye(m) + S' * S) * S';
else
    G = S' * inv(speye(p) + S * S');
end

dx = A * G * s;

if rfactor ~= 1
    S = S / sqrt(rfactor);
    if strcmp(prm.method, 'ETKF')
        M = inv(speye(m) + S' * S);
        G = M * S';
    elseif m <= p
        G = inv(speye(m) + S' * S) * S';
    else
        G = S' * inv(speye(p) + S * S');
    end
end

switch prm.method
    case 'EnKF'
        A = A * (speye(m) + G * (D - S));
    case 'DEnKF'
        A = A * (speye(m)- 0.5 * G * S);
    case 'ETKF'
        A = A * sqrtm(M);
    case 'Potter'
        T = eye(m);
        for o = 1 : p
            So = S(o, :);
            SSo = So * So' + 1;
            To = So' * (So / (SSo + sqrt(SSo)));
            S = S - S * To;
            T = T - T * To;
        end
        A = A * T;
    case 'EnOI'
        % do nothing
    otherwise
        error(sprintf('\n  EnKF: error: assimilate(): method \"%s\" is not defined for the asyncronous EnKF', prm.method));
end


return
