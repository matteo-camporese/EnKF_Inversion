%SetProbabilities

function P1 = SetProbabilities(Priority,level)

%Prob = [10 2 1;5 19 1;1 1 2];
Prob = [10 0 0;10 2 1;5 19 1];
P = zeros(size(Priority));
for j=1:size(Priority,2)
      if (Priority(j) == 1)
            P(j) = Prob(level,1);
      elseif (Priority(j) == 2)
            P(j) = Prob(level,2);
      else
            P(j) = Prob(level,3);
      end%if
end;%for j
P1 = P/sum(P);


