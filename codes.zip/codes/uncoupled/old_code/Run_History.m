load level3_level2;

load meas_data.txt;
Measurement.meas_data=meas_data;
[Measurement]=Generate_Roughness(Measurement);

N=VecLength;

if N==1, Rough=[1]; end;
if N==18, Rough=Measurement.Rough18; end;
if N==72, Rough=Measurement.Rough72; end;
if N==450, Rough=Measurement.Rough450; end;
if N==1800, Rough=Measurement.Rough1800; end;

for i=1:1000
    par=(StoredBest(i,1:VecLength));
    OF_smooth=0.01*mean(abs(Rough*par'));
    par=log10(par);
    Best=reshape(par,[15,30]);
    tmp1 = [Best Best(:,30)];
    tmp2=[tmp1;tmp1(15,:)];
    pcolor(tmp2), caxis([1 4]), colorbar, title (['Model Fit:',num2str(StoredBest(i,VecLength+1)-OF_smooth),'    Smoothness:',num2str(OF_smooth),'    Iteration:', num2str(i)])

    pause(0.1)
end