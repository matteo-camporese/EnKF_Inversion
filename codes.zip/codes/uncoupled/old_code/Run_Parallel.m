% How many nodes are being used
%available_nodes = 11;
available_nodes = 4;

% Define global variables
global tag = 42; global nodes = -1; global rank = -1; global world = -1;
%global ModelName='Calc_OF_Unix';
global ModelName='Calc_OF';

disp("caste:");
disp(caste);
% Initialize the MPI network
[rank,nodes,world] = initmpi(caste,available_nodes);

%disp('Generated measurements')
load meas_data.txt;
global Measurement;
Measurement.meas_data=meas_data;
[Measurement]=Generate_Roughness(Measurement);

% Run the master and slaves
if (caste == master)
   ERT_GA_Inv
else
   ga_slave      
end;
