%MutationsByExchange2
% function [Out] = MutationsByExchange(In,NumOfMutations)
% 
% %this function created tail mutations from the elite group. It gets as input the
% %elite group (In) and creates NumOfMutations mutations. Note that
% %NumOfMutations is assumed to be even (this is not checked by the function)
% 
% [m,n] = size(In);
% Out = zeros(NumOfMutations,n);
% for i=1:NumOfMutations/2
%       Sources = randsrc(1,2,[1:m;1/m*ones(1,m)]);
%       CrossPoint = randsrc(1,1,[2:n-3;1/(n-4)*ones(1,n-4)]);
%       Out((i-1)*2+1,:) = [In(Sources(1),1:CrossPoint) In(Sources(2),CrossPoint+1:n)];
%       Out(i*2,:) = [In(Sources(2),1:CrossPoint) In(Sources(1),CrossPoint+1:n)];
% end
% Out(:,n-1) = ones(NumOfMutations,1);%indication that was created by exchange

% THIS FUNCTION IS A REPLACEMENT FOR THE ORIGINAL
% FUNCTION. THE DIFFERENCE IS THAT INSTEAD OF
% TAIL EXCHANGE MUTATIONS IT CREATES VARIABLE
% EXCHAGES IN THE TWO CHROMOSOMES (I.E. CROSSES
% GENES BETWEEN THE TWO CHROMOSOMES NOT NECESARILY
% ALONG A STRING)
% 
function [Out] = MutationsByExchange2(In,NumOfMutations,Probability)

%this function created mutations from the elite group. It gets as input the
%elite group (In) and creates NumOfMutations mutations. Note that
%NumOfMutations is assumed to be even (this is not checked by the function)

[m,n] = size(In);
Out = zeros(NumOfMutations,n);
for i=1:NumOfMutations/2
      Sources = randsrc(1,2,[1:m;1/m*ones(1,m)]);
      Num = randsrc(1,1,[1:n-2;1/(n-2)*ones(1,n-2)]);
      Out((i-1)*2+1,:) = In(Sources(1),:);
      Out(i*2,:) = In(Sources(2),:);
      for j=1:Num
            Loc = randsrc(1,1,[1:(n-2);Probability]);
            Out((i-1)*2+1,Loc) = In(Sources(2),Loc);
            Out(i*2,Loc) = In(Sources(1),Loc);
      end;
end
Out(:,n-1) = ones(NumOfMutations,1);%indication that was created by exchange

