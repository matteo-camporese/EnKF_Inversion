% Wait for data, process it and return it.

% Termination?
function ga_slave()
   global world; global tag; global nodes; global rank; global ModelName; global Measurement;
  while (1 == 1)
    NumPar=450;
    [minfo mstat] = MPI_Probe(-1,-1,world);
    [minfo dbls] = MPI_Get_elements(mstat,[]);
    printf("new package size: %d\n",dbls);      
    N = zeros(1,dbls);
    [minfo mstat] = MPI_Recv(N,-1,tag,world);
    % Get the parameters
    x = reshape(N, dbls/NumPar, NumPar);
    % Define the size of x
    [nrsets  nrpars] = size(x);
    % Check this
    global CopyOrNot 
    % If 'Yes' copy all the files locally before running the model
    if (1 == 1);
       % Copy files to scratch of the node
       evalstr = strcat('mkdir /home/campo/ParallelGA/scratch',num2str(rank)); unix(evalstr);
       % Now go to home directory
       cd /home/campo/ParallelGA/crmod
       % Copy the files from home directory to local node
       evalstr = strcat('cp -pfr * /home/campo/ParallelGA/scratch',num2str(rank)); unix(evalstr);
       % And go to the appropriate directory
       evalstr = strcat('cd /home/campo/ParallelGA/scratch',num2str(rank)); 
       eval(evalstr); 
    end;
    jevalstr = strcat('cd /home/campo/ParallelGA/scratch',num2str(rank)); eval(jevalstr);
    % Then evaluate each combination of x
    for i=1:nrsets
        evalstr = ['OF = ',ModelName,'(x(i,1:nrpars),Measurement);']; 
        eval(evalstr,'pwd;printf("rank: %d\n",rank);');
        out(i,:) = OF;
    endfor
    % Change value of CopyOrNot -- creating local directory only needs to happen once
    CopyOrNot = 0;
    % Return the result   
    [dummy nrelts] = size(OF);
    package = reshape(out, 1, nrsets*nrelts);
    MPI_Send(package,0,tag,world);
    clear out;
  endwhile
endfunction

% eof.
