%   ERT_EnKF_inv

clear
% Definition of parameters
%*************************************
%global Population;
EliteSize = 10; %size of elite group (from which mutations are generated)
StockSize = 5000; %size of population in each iteration (generation)
NumberOfGenerations = 1;
NumberMutationsByExchange = 0;%must be an even number
NumberMutationsByPerturbation = 0; %
NumberOfPerturbationsPerVector = 0; % Need to make sure this value is not larger than the vector size
NumberOfNewRandomMutations = 5000;% the idea is to continuously introduce more randomly generated genes to avoid being stucked in local minima
% Note that EliteSize + NumberMutationsByExchange +
% NumberMutationsByPerturbation must be equal (or smaller but no point in
% doing that)  to the StockSize
RMS_History = zeros(NumberOfGenerations);

Parallel = 0; %0=single processor version; 1=multiprocessor version (start with master.m)
grid = 4; %1=3x6; 2=6x12; 3=15x30; 4=30x60
ValuesVec = [10.^(-1.25:0.25:1.50);0.0020 0.0087 0.0314 0.0827 0.1576 0.2176 0.2176 0.1576 0.0827 0.0314 0.0087 0.0020];
% This vector contains the possible values.
% We avoid using the full spectrum of values and discretize the spectrum to 9 values.
% The second row of the matrix contains probabilities for each value

LoadFromCoarser = 1;%flag indication for source of initial ensemble - from spatially correlated or not RFG. 0 = no correlation; 1 = correlation
%If LoadFromCoarser = 2 it starts from coarser solution. The source file name is located in the LoadCoarser.m file

if (Parallel <= 0)
    % Generate_Forward_Run;
    Generate_Forward_Run_Layers;
    disp('Generated measurements')
    meas_data=load('meas_data.txt');
    global Measurement;
    Measurement.meas_data=meas_data;
    [Measurement]=Generate_Roughness(Measurement);
end;

if (Parallel == -1)
    disp('Cosa vuoi fare adesso?')
    pause
end;

Priority = SetPriority(grid,1);
TruncatedPriority = SetPriority(grid,0);
switch(grid)
    case 1
        VecLength = 18;
        disp('working on 3x6 grid')
        P = zeros(1,18);
    case 2
        VecLength = 72;
        disp('working on 6x12 grid')
        P = zeros(1,72);
    case 3
        VecLength = 450;
        disp('working on 15x30 grid')
        P = zeros(1,450);
    case 4
        VecLength = 1800;
        disp('working on 30x60 grid')
        P = zeros(1,1800);
end;%switch

StoredBest = zeros(NumberOfGenerations,VecLength + 3);% here the best outputs will be stored. The last columns are for the performance (RMS),
%source (random, exchange, mutation), and the generation it was created
Population = zeros(StockSize,VecLength+2);% the extra 2 are a tag to indicate gene source (0 = random, 1 = exchange, 2 = mutation; 4 = from coarser solution) and generation is was created

switch (LoadFromCoarser)
    case 0
        % Generate initial population
        Population = [randsrc(StockSize,VecLength,ValuesVec) zeros(StockSize,1) ones(StockSize,1)];
    case 1
        % Generate initial population from SKSIM
        cd popinit/
        seed = mod(ceil(cputime*99999),2^32);
        nmc = StockSize;
        SEED = [seed nmc];
        save seed.dat -ascii SEED;
        [s,w]=unix('./generate');
        kk=load('generate.kkk');
        kk=reshape(kk,VecLength,StockSize);
        kk=kk';
        kk=(round(log10(kk).*4))./4;
        cd ../
        for i=1:StockSize
            Population(i,1:VecLength)=switchgrid(10.^(kk(i,:)),30,60);
            Population(i,VecLength+1)=0;
            Population(i,VecLength+2)=1;
        end
    case 2
        %this is for loading solution of coarser grid
        Population(1:StockSize,:) = LoadCoarser(1,StockSize);
%         Population(1:EliteSize,:) = LoadCoarser(1,EliteSize);
%         P1 = SetProbabilities(Priority,1);
%         Population(EliteSize+1:EliteSize+NumberMutationsByExchange,:) = MutationsByExchange2(Population(1:EliteSize,:),NumberMutationsByExchange,P1);
%         Population(EliteSize+1:EliteSize+NumberMutationsByExchange,VecLength+2) = ...
%             1 * ones(NumberMutationsByExchange,1);%indication date of creation
%         Population(EliteSize+NumberMutationsByExchange+1:EliteSize+NumberMutationsByExchange+NumberMutationsByPerturbation,:) = ...
%             MutationsByPerturbation(Population(1:EliteSize,:),NumberOfPerturbationsPerVector,NumberMutationsByPerturbation,ValuesVec,P1);
%         Population(EliteSize+NumberMutationsByExchange+1:EliteSize+NumberMutationsByExchange+NumberMutationsByPerturbation,VecLength+2) = ...
%             1 * ones(NumberMutationsByPerturbation,1);%indication date of creation
%         Population(EliteSize+NumberMutationsByExchange+NumberMutationsByPerturbation+1:EliteSize+NumberMutationsByExchange+NumberMutationsByPerturbation+NumberOfNewRandomMutations,:) = ...
%             [randsrc(NumberOfNewRandomMutations,VecLength,ValuesVec) zeros(NumberOfNewRandomMutations,1) 1 * ones(NumberOfNewRandomMutations,1)];
end;

switch (Parallel)
    case 0
        % Generate observations for each ensemble member
        disp('Evaluating observations')
        for i=1:StockSize
            [RMS(:,i),CONC(:,i)] = Calc_OF(Population(i,1:VecLength),Measurement);
        end;
    case 1
        % Parallel Implementation
        Pars=Population(1:StockSize,1:VecLength);
        global NumPar;
        NumPar=VecLength;
        RMS=DoParallel(Pars);
end;

% Sort and keep elite
% [RMS,Index] = sort(RMS);
% Population_tmp = Population;
% for j=1:EliteSize
%       Population(j,:) = Population_tmp(Index(j),:);
% end;
% disp('Generation #, best RMS  ')
% [1 RMS(1)]
% StoredBest(1,1:VecLength) = Population(1,1:VecLength);
% StoredBest(1,VecLength+1) =  RMS(1);
% StoredBest(1,VecLength+2:VecLength+3) = Population(1,VecLength+1:VecLength+2);
% RMS_History(1) = RMS(1);

% Ensemble Kalman Filter

save -v7 before.mat

prm.m = StockSize;
prm.n = VecLength;
prm.obs_variance = 0.01;
prm.rfactor1 = 1.0;
prm.rfactor2 = 1.0;
prm.method = 'EnKF';

% calculate ensemble anomalies
%
% E = [CONC; log10(Population(:,1:VecLength)')];
E = log10(Population(:,1:VecLength)');
x = mean(E')';
A = E - repmat(x, 1, StockSize);
y = log10(meas_data);
HE = log10(RMS);
Hx = mean(HE')';
dy = y - Hx;
HA = HE - repmat(Hx, 1, StockSize);

[dx, A] = assimilate(prm, A, HA, dy);

x = x + dx;
E = A + repmat(x, 1, StockSize);

save -v7 after.mat
save prova-log.dat x -ascii
