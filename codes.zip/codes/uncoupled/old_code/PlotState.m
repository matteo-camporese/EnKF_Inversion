%plotState
function PlotState (Population,grid,RMS_History)

figure(1)
switch(grid)
      case 1
            Best = zeros(3,6);
            for k=1:6
                  for l=1:3
                        Best(l,k) = log10(Population(1,(k-1)*3+l));
                  end;
            end;
            tmp1 = [Best Best(:,6)];
            tmp2=[tmp1;tmp1(3,:)];
            pcolor(tmp2), caxis([1 4]), colorbar
      case 2
            Best = zeros(6,12);
            for k=1:12
                  for l=1:6
                        Best(l,k) = log10(Population(1,(k-1)*6+l));
                  end;
            end;
            tmp1 = [Best Best(:,12)];
            tmp2=[tmp1;tmp1(6,:)];
            pcolor(tmp2), caxis([1 4]), colorbar
            
      case 3
            Best = zeros(15,30);
            for k=1:30
                  for l=1:15
                        Best(l,k) = log10(Population(1,(k-1)*15+l));
                  end;
            end;
            tmp1 = [Best Best(:,30)];
            tmp2=[tmp1;tmp1(15,:)];
            pcolor(tmp2), caxis([1 4]), colorbar
      case 4
            Best = zeros(30,60);
            for k=1:60
                  for l=1:30
                        Best(l,k) = log10(Population(1,(k-1)*30+l));
                  end;
            end;
            tmp1 = [Best Best(:,60)];
            tmp2=[tmp1;tmp1(30,:)];
            pcolor(tmp2), caxis([1 4]), colorbar
end;%switch
figure(2)
semilogy(RMS_History)

