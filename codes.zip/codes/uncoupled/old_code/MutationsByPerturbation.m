%MutationsByPerturbation
%This function creates mutations in the imputs ("In", the elite group) that
%it gets. The number of mutations per vector ("NumOfPerturbs") and their
%locations in the vector are randomally selected

function Out = MutationsByPerturbation(In,NumOfPerturbs,NumOfMutations,Variaty,Probability)

[m,n] = size(In);
Out = zeros(NumOfMutations,n);

for i=1:NumOfMutations
      Source = randsrc(1,1,[1:m;1/m*ones(1,m)]);
      Num = randsrc(1,1,[1:NumOfPerturbs;1/NumOfPerturbs*ones(1,NumOfPerturbs)]);%number of perturbs per vector
      Out(i,:) = In(Source,:);
      for j=1:Num
            Loc = randsrc(1,1,[1:(n-2);Probability]);
            Val = randsrc(1,1, Variaty);%new value to assign
            Out(i,Loc) = Val;
      end;
      Out(i,n-1) = 2;%indicating creation by perturbation
end;

