%Downscale

function Out = Downscale(In,OutputLevel)

%this function downscales values between different grid resolutions. It
%accepts as input a vector that includes resistivities, and translates it
%to finer grid resistivities. The function assumes that it needs to
%downscale only one level, i.e. from coarse to intermediate or from
%intermediate to fine. It does not consider at this point full downscaling
%from coarse to fine

switch(OutputLevel)
      case 1
            disp('can not downscale to this level')
            Out = In;
      case 2
            disp('converting from 3x6 to 6x12')
            Out = zeros(1,6*12);
            for j=1:6
                  for k=1:2
                        for i=1:3
                              for l=1:2
                                    Out(1,(j-1)*12+(k-1)*6+(i-1)*2+l) = In((j-1)*3+i);
                              end;
                        end;%k
                  end;%j
            end;%i
      case 3
            disp('converting from 6x12 to 15x30')
            % going first to the finest level
            tmp = zeros(1,30*60);
            for j=1:12
                  for k=1:5
                        for i=1:6
                              for l=1:5
                                    tmp(1,(j-1)*150+(k-1)*30+(i-1)*5+l) = In((j-1)*6+i);
                              end;
                        end;%k
                  end;%j
            end;%i
            % now going back to the coarser level
            Out = zeros(1,15*30);
            for j=1:30
                  for i=1:15
                        val1 = tmp((i-1)*2+(j-1)*15*2*2+1);
                        val2 = tmp((i-1)*2+(j-1)*15*2*2+2);
                        val3 = tmp((i-1)*2+(j-1)*15*2*2+1+30);
                        val4 = tmp((i-1)*2+(j-1)*15*2*2+2+30);
                        Out((j-1)*15+i) = mean([val1 val2 val3 val4]);
                  end;
            end;
            

      case 4
            disp('converting from 15x30 to 30x60')
            Out = zeros(1,30*60);
            for j=1:30
                  for k=1:2
                        for i=1:15
                              for l=1:2
                                    Out(1,(j-1)*60+(k-1)*30+(i-1)*2+l) = In((j-1)*15+i);
                              end;
                        end;%k
                  end;%j
            end;%i
      case 5
            disp('converting from 3x6 to 15x30')
            Out = zeros(1,15*30);
            for j=1:6
                  for k=1:5
                        for i=1:3
                              for l=1:5
                                    Out(1,(j-1)*75+(k-1)*15+(i-1)*5+l) = In((j-1)*3+i);
                              end;
                        end;%k
                  end;%j
            end;%i
      case 6
            disp('converting from 3x6 to 30x60')% NOT YET IMPLEMENTED
      case 7
            disp('converting from 6x12 to 30x60')% NOT YET IMPLEMENTED
end;%switch





