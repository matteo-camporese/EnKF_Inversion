%Truncated2Full

function Out =  Truncated2Full(Truncated,Resolution)

[m,n] = size(Truncated);

switch(Resolution)
      case 1
            Out = zeros(m,3*6+2);
            disp('in Truncated2Full -> coarse grid')
            for i=1:3
                  Out(:,i) = Truncated(:,9);
            end;
            for j=1:4
                  for i=1:2
                        Out(:,3+(j-1)*3+i) = Truncated(:,(j-1)*2+i);
                  end;%i
                  Out(:,3+j*3) = Truncated(:,9);
            end;%j
            for i=15:18
                  Out(:,i) = Truncated(:,9);
            end;
            Out(:,19:20) = Truncated(:,n-1:n);
      case 2
            Out = zeros(m,15*30+2);
            disp('in Truncated2Full -> intermediate resolution grid')
            for i=1:75
                  Out(:,i) = Truncated(:,201);
            end;
            for j=1:20
                  for i=1:10
                        Out(:,75+(j-1)*15+i) = Truncated(:,(j-1)*10+i);
                  end;%i
                  for k=1:5
                        Out(:,75+(j-1)*15+10+k) = Truncated(:,201);
                  end;%k
            end;%j
            for i=376:450
                  Out(:,i) = Truncated(:,201);
            end;
            Out(:,451:452) = Truncated(:,n-1:n);
      case 3
            Out = zeros(m,30*60+2);
            disp('in Truncated2Full -> fine grid')
            for i=1:300
                  Out(:,i) = Truncated(:,801);
            end;
            for j=1:40
                  for i=1:20
                        Out(:,300+(j-1)*30+i) = Truncated(:,(j-1)*20+i);
                  end;%i
                  for k=1:10
                        Out(:,300+(j-1)*30+20+k) = Truncated(:,801);
                  end;%k
            end;%j
            for i=1501:1800
                  Out(:,i) = Truncated(:,801);
            end;
            Out(:,1801:1802) = Truncated(:,n-1:n);
end;

