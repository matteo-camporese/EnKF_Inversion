function [OF] = DoParallel(x);
% Distributes the parameter combinations and runs the model on each individual node

global nodes; 

% Then evaluate each individual of x
[OF] = mpirun(x,1,nodes);
