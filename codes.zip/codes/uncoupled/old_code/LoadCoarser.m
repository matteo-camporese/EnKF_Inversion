%LoadCoarser

function Out = LoadCoarser(level,EliteSize)

Coarser = load('level22level3tris.dat');

switch (level)
      case 1
            disp('in LoadCoarser -> can not downscale to this level')
      case 2
            disp('LoadCoarser -> downscaling from 3x6 to 6x12')
      case 3
            disp('LoadCoarser -> downscaling from 6x12 to 15x30')
            Out = zeros(EliteSize,450);
      case 4
            disp('LoadCoarser -> downscaling from 15x30 to 30x60')
            Out = zeros(EliteSize,1800);
      case 5
            disp('LoadCoarser -> downscaling from 3x6 to 15x30')
            Out = zeros(EliteSize,450);
      case 6
            disp('LoadCoarser -> downscaling from 3x6 to 30x60')
            Out = zeros(EliteSize,1800);
      case 7
            disp('LoadCoarser -> downscaling from 6x12 to 30x60')
            Out = zeros(EliteSize,1800);
end;

tmp = Downscale(Coarser(size(Coarser,1),1:size(Coarser,2)-3),level);
for i=1:EliteSize
      Out(i,:) = tmp;
end;
Out = [Out zeros(EliteSize,1) 4*ones(EliteSize,1)];


