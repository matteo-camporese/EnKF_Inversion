% Ensemble smoother
delete ES.m~;

% load simulated and measured data
load mcfean/conc.dat
load ../../prove/testcase3/2000/before.mat

% assemble measurement vector
j=0;
for i=1:14400;
    if conc(i) > 0.0
        j=j+1;
        CSIM(j,:)=CONC(i,:);
        CMIS(j)=conc(i);
    end
end
CMIS=CMIS';

prm.m = StockSize;
prm.n = VecLength;
prm.obs_variance = 0.01;
prm.rfactor1 = 1.0;
prm.rfactor2 = 1.0;
prm.method = 'EnKF';

% Normal score transform of ensemble members for each node
% for i=1:VecLength;
%     d=(Population(:,i)');
%     %d=log10(Population(:,i)');
%     [d_nscore(:,i),o_nscore(i)]=nscore(d,1,1,min(d),max(d),0);
% end
% E = [CONC; log10(Population(:,1:VecLength)')];
% E = d_nscore';

% Aggregate normal score transform
% d=Population(:,1:1800);
% d=reshape(d',1,1800*StockSize);
% [d_nscore,o_nscore]=nscore(d,1,1,min(d),max(d),0);
% E = reshape(d_nscore,1800,StockSize);

% Log10 transform
E = log10(Population(:,1:VecLength)');

% calculate ensemble anomalies

x = mean(E,2);
A = E - repmat(x, 1, StockSize);

% Assimilate ERT data ...
% y = log10(meas_data);
% y = meas_data;
% HE = log10(RMS);
% HE = RMS;
% ... or concentration data
y = CMIS;
HE = CSIM;

DD = repmat(y, 1, StockSize);
% DY = DD-HE;

% NST for each node
for i=1:size(y,1)
    d=DD(i,:)-HE(i,:);
    [DY(i,:),m_nscore]=nscore(d,1,1,min(d),max(d),0);
    d=HE(i,:);
    [HE(i,:),m_nscore]=nscore(d,1,1,min(d),max(d),0);
end

% Aggregate NST
% d = reshape(DD-HE,1,1112*StockSize);
% [DY,m_nscore]=nscore(d,1,1,min(d),max(d),0);
% DY = reshape(DY,1112,StockSize);
% d = reshape(HE,1,1112*StockSize);
% [HE,m_nscore]=nscore(d,1,1,min(d),max(d),0);
% HE = reshape(HE,1112,StockSize);

Hx = mean(HE,2);
dy = mean(DY,2);
% dy = y - Hx;
HA = HE - repmat(Hx, 1, StockSize);
% for i=1:size(HA,1)
%     d=HA(i,:);
%     [HA(i,:),m_nscore(i)]=nscore(d,1,1,min(d),max(d),0);
% end

[dx, A] = assimilate(prm, A, HA, dy);

x = x + dx;
E = A + repmat(x, 1, StockSize);

% Back transform ensemble for each node
% for i=1:VecLength;
%     d=E(i,:);
%     E(i,:)=inscore(d,o_nscore(1,i));
% end

% Back transform aggregate
% d = reshape(E,1,1800*StockSize);
% E = inscore(d,o_nscore);
% E = reshape(E,1800,StockSize);

x = mean(E,2);
% x = log10(x);
save '/Users/campo/Work/papers/conferences/AGU2011/GAvsEnKF/prove/testcase3/after.mat'