function [OF]=assemblaHE(par,nupd,ndim)

OF=[];
bot=nupd*ndim+1;
top=(nupd+1)*ndim;
for mc=1:size(par,2);
    parcr=par(bot:top,mc);
    parcr=switchgrid(parcr,30,60);
    SIGMA = reshape(parcr,30,60);
    k = 0;
    for i=1:2:30;
        for j=1:2:60;
            k=k+1;
            SIGMAL(k) = log(SIGMA(i,j));
        end
    end
    OF=[OF SIGMAL'];
end
return
