%   ERT_EnKF_inv

clear
% Definition of parameters
%*************************************
%global Population;
VecLength = 1800;
StockSize = 2500; %ensemble size
nvmeas = 450; %number of rho measurements (from ERT inversions)
CV = 0.05; %Coefficient of variation of the measurements
% Parameters of the EnKF
prm.m = StockSize;
prm.n = VecLength;
prm.obs_variance = log(1+CV^2);
prm.rfactor1 = 1.0;
prm.rfactor2 = 1.0;
prm.method = 'EnKF';


Parallel = 0; %0=single processor version; 1=multiprocessor version (start with master.m)

% if (Parallel <= 0)
%     % Generate_Forward_Run;
%     Generate_Forward_Run_Layers;
%     disp('Generated measurements')
%     meas_data=load('meas_data.txt');
%     global Measurement;
%     Measurement.meas_data=meas_data;
% end;

if (Parallel == -1)
    disp('Cosa vuoi fare adesso?')
    pause
end;

% disp('working on 30x60 grid')
% P = zeros(1,1800);

Population = zeros(StockSize,VecLength);

% Generate initial population from SKSIM
cd popinit/
seed = mod(ceil(cputime*99999),2^32);
nmc = StockSize;
SEED = [seed nmc];
save seed.dat -ascii SEED;
[s,w]=unix('./generate');
kk=load('generate.kkk');
kk=reshape(kk,VecLength,StockSize);
kk=kk';
cd ../
for i=1:StockSize
    Population(i,:)=switchgrid(kk(i,:),30,60);
end
Y=log10(Population');
for nupd=1:8;
    switch (Parallel)
        case 0
            % Generate observations for each ensemble member
            disp('Evaluating observations')
            for i=1:StockSize
                [RMS(:,i),CONC(:,i)] = Calc_OF(Population(i,:),nupd);
            end;
        case 1
            % Parallel Implementation, not implemented yet
            %         Pars=Population(1:StockSize,1:VecLength);
            %         global NumPar;
            %         NumPar=VecLength;
            %         RMS=DoParallel(Pars);
    end;

    % Ensemble Kalman Filter

    % calculate ensemble anomalies
    %
    % E = [CONC; log(Population(:,1:VecLength)')];
    E = log(Population');
    x = mean(E,2);
    A = E - repmat(x, 1, StockSize);
    % Load rho measurements
    filename=['covT',num2str(nupd+1,'%1.0f'),'/rho.dat'];
    y = load(char(filename));
    y = log(1./y);
    HE = assemblaHE(RMS,nupd,VecLength);
    Hx = mean(HE,2);
    dy = y - Hx;
    HA = HE - repmat(Hx, 1, StockSize);
    % Load observation error covariance matrix
    filename=['covT',num2str(nupd+1,'%1.0f'),'/Re.dat'];
    Re = load(char(filename));

    [dx, A] = assimilate(prm, A, HA, dy, Re);

    x = x + dx;
    E = A + repmat(x, 1, StockSize);
    Population=exp(E');
    Y=[Y; log10(Population')];
end
save -v7 output.mat
save Yensemble.dat Y -ascii
