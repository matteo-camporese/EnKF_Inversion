function [OF,conc]=Calc_OF(par,nupd)

% Meas_Data=Measurement.meas_data;

% N=size(par,2);

% if N==1, Rough=[1]; end;
% if N==18, Rough=Measurement.Rough18; end;
% if N==72, Rough=Measurement.Rough72; end;
% if N==450, Rough=Measurement.Rough450; end;
% if N==1800, Rough=Measurement.Rough1800; end;
%
% OF_smooth=mean(abs(Rough*par'));

% Renumber parameters for mcfean grid
% parmc=switchgrid(par,30,60);
% Call mcfean
disp('call mcfean');
cd mcfean
Write_Kappa(par);
[s,w]=unix('./mcfeansf');
% Open concentration data and transform into sigma values
[nstep,ndim,conc]=plume;
sigma=9.004.*conc+0.0021;
rho=1./sigma;

% leave model directory

cd ..

OF=sigma;
return
