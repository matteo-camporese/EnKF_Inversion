c           ndm   numero massimo dei nodi di calcolo
c                 [nly1*npti+1]*[nly2*npti+1]
c           nnmax numero massimo di valori nonnulli della matrice
c                 (nnriga*ndm)
c           nelmax numero massimo degli elementi di calcolo
c                  [nly1*npti]*[nly2*npti]
c           lag   numero massimo intervalli di calcolo delle covarianze
c                 eguale a 20*npti
c           nly   numero di scale integrali per valutare la varianza
c                 di vy e vy euleriane (larghezza della striscia)
c           nft   valore minimo 2^n o 2*npsi*max(nly1,nly2)
c           nftsq2 il doppio del quadrato di nft
c
      parameter(ndm=2145,nnmax=10725,nelmax=2048,lag=81,
     &          nft=256,nftsq2=131072)
cm    parameter(ndm=25921,nnmax=129605,nelmax=25600,lag=81,
cm   &          nft=512,nftsq2=524288)
