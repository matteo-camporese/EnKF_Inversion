function [nprt,ndim,CONC]=plume
% close all;
% clear all;
% delete plume.m~;
fid = fopen('technion.con','r');
a=0;
b=0;
nprt=0;
TIME=[];
CONC=[];
nens=1;
nd1=30;
nd2=15;
npti=2;
n1=nd1*npti;
n2=nd2*npti;
ndim=n1*n2;
dx=1/npti;
dy=1/npti;
while (a~=(-1))        % Find out number of time values for detailed nodal output (nprt)
    a = fgetl(fid);
    if (a~=(-1))       % Loops trough fid until b=-1 end of file
        c = double(a);
    end
    if c(2:6)==[110 115 116 101 112] % c(2:5)='nstep'
        nprt = nprt+1;
    end
end
frewind(fid);
for b=1:nprt
    time = fscanf(fid,'%*10c %g',1);
    TIME = [TIME;time];
    %     if nens == 1
    conc = fscanf(fid,'%g',ndim);
    %     else
    %         conc = fscanf(fid,'%g',[nens,ndim]);
    %     end
    %conc = conc';
    CONC = [CONC; conc];
end
[m,n]=size(TIME);
if m ~= nprt
    for b=1:nprt
        time = fscanf(fid,'%*10c %g',1);
        TIME = [TIME;time];
        %     if nens == 1
        conc = fscanf(fid,'%g',ndim);
        %     else
        %         conc = fscanf(fid,'%g',[nens,ndim]);
        %     end
        %conc = conc';
        CONC = [CONC; conc];
    end
end
fclose(fid);
