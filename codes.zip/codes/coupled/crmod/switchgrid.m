function [newgrid]=switchgrid(oldgrid,m,n)

% Switch from the crmod numbering to the mcfean numbering and vice versa

newgrid=reshape(flipud(reshape(oldgrid,m,n)),1,m*n);