function Write_Rho(par)

%This file writes the resisitivity values into rho.dat. The parameter
%vector should be a row of values (or line 8 needs to be changed).

Grid=0;

N=size(par,2);

if N==1, Grid=1; end;
if N==18, Grid=2; end;
if N==72, Grid=3; end;
if N==450, Grid=4; end;
if N==1800, Grid=5; end;


switch(Grid)
      case 0 % Catch inappropriate size or dimension of parameter vector
            Error='Size of parameter not appropriate. Check size and dimension.'
            return
            
      case 1 % Homogeneous half space
            count=1;
            Rho(1:1800,1)=par(1)*ones([1800,1]);
            fid = fopen('rho.dat','wt');
            NrElem=1800;
            fprintf(fid,'%6.0f\n',NrElem);
            
            for i=1:NrElem
                  fprintf(fid,'%f\n',Rho(i));
            end
            fclose(fid);
            
      case 2 %write the 3*6 grid
            count=1;
            for i=1:6
                  for j=1:10
                        for k=1:3
                              for l=1:10
                                    Rho(count,1)=par(k+(i-1)*3);
                                    count=count+1;
                              end
                        end
                  end
            end
            
            fid = fopen('rho.dat','wt');
            NrElem=size(Rho,1);
            fprintf(fid,'%6.0f\n',NrElem);
            
            for i=1:NrElem
                  fprintf(fid,'%f\n',Rho(i));
            end
            
            fclose(fid);
      
    case 3 %write the 6*12 grid
            count=1;
            for i=1:12
                  for j=1:5
                        for k=1:6
                              for l=1:5
                                    Rho(count,1)=par(k+(i-1)*6);
                                    count=count+1;
                              end
                        end
                  end
            end
            
            fid = fopen('rho.dat','wt');
            NrElem=size(Rho,1);
            fprintf(fid,'%6.0f\n',NrElem);
            
            for i=1:NrElem
                  fprintf(fid,'%f\n',Rho(i));
            end
            
            fclose(fid);  
            
            
            
      case 4 %write the 15*30 grid
            count=1;
            for i=1:30
                  for j=1:2
                        for k=1:15
                              for l=1:2
                                    Rho(count,1)=par(k+(i-1)*15);
                                    count=count+1;
                              end
                        end
                  end
            end
            
            fid = fopen('rho.dat','wt');
            NrElem=size(Rho,1);
            fprintf(fid,'%6.0f\n',NrElem);
            
            for i=1:NrElem
                  fprintf(fid,'%f\n',Rho(i));
            end
            
            fclose(fid);
            
      case 5 %write the 30*60 grid
            Rho=par;
            fid = fopen('rho.dat','wt');
            NrElem=1800;
            fprintf(fid,'%6.0f\n',NrElem);
            
            for i=1:NrElem
                  fprintf(fid,'%f\n',Rho(i));
            end
            
            fclose(fid);
end;
