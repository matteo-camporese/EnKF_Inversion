function [OF]=Calc_OF_Unix(par,Measurement)

Meas_Data=Measurement.meas_data;

N=size(par,2);

if N==1, Rough=[1]; end;
if N==18, Rough=Measurement.Rough18; end;
if N==72, Rough=Measurement.Rough72; end;
if N==450, Rough=Measurement.Rough450; end;
if N==1800, Rough=Measurement.Rough1800; end;

OF_smooth=0.01*mean(abs(Rough*par'));

% Go to the model directory

% Write_Rho_Coarse(par);
Write_Rho(par);

% Switch between Unix and Windows version
[s,w]=unix('./CRUnix.exe');

fid = fopen('volt.dat','r');
[NrArrays]=fscanf(fid,'%g',[1 1]);
for i=1:NrArrays
      Sim_Data(i,1:3)=fscanf(fid,'%g %g %g',[1 3]);
end
fclose(fid);

% leave model directory

OF=sum((Meas_Data-Sim_Data(:,3)).^2)+OF_smooth;
